function Request(path, method, body) {

  this.path = path;

  this.method = method;

  this.body = body;

}
