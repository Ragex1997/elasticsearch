function ModalControls() {
  this.alert = null;
  this.active = false;
  this.title = '';
  this.info = '';
}
